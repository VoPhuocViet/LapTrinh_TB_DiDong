import React from "react";
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, SafeAreaView } from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import caNauLau from "../assets/ca_nau_lau.png";
import gaBotoi from "../assets/ga_bo_toi.png";
import xeCau from "../assets/xa_can_cau.png";
import doChoi from "../assets/do_choi_dang_mo_hinh.png";
import snack from "../assets/snack-icon.png";
import hieuLong from "../assets/hieu_long_con_tre.png";
// Dữ liệu mẫu cho FlatList
const data = [
  {
    id: "1",
    image: caNauLau,
    title: "Ca nấu lẩu, nấu mì mini...",
    shop: "Shop Devang",
    shopColor: "#FF3366",
  },
  {
    id: "2",
    image: gaBotoi,
    title: "1KG KHÔ GÀ BƠ TỎI ...",
    shop: "Shop LTD Food",
    shopColor: "#FF3366",
  },
  {
    id: "3",
    image: xeCau,
    title: "Xe cần cẩu đa năng",
    shop: "Shop Thế giới đồ chơi",
    shopColor: "#888",
  },
  {
    id: "4",
    image: doChoi,
    title: "Đồ chơi dạng mô hình",
    shop: "Shop Thế giới đồ chơi",
    shopColor: "#888",
  },
  {
    id: "5",
    image: snack,
    title: "Lãnh đạo giản đơn",
    shop: "Shop Minh Long Book",
    shopColor: "#888",
  },
  {
    id: "6",
    image: hieuLong,
    title: "Hiểu lòng con trẻ",
    shop: "Shop Minh Long Book",
    shopColor: "#888",
  },
];

export default function ChatListScreen() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#f5f5f5" }}>
      {/* Header */}
      <View style={styles.header}>
        <Ionicons name="arrow-back" size={24} color="#222" style={{ marginLeft: 6 }} />
        <Text style={styles.headerTitle}>Chat</Text>
        <MaterialIcons name="shopping-cart" size={24} color="#fff" style={{ marginRight: 10 }} />
      </View>
      {/* Notification */}
      <View style={styles.notify}>
        <Text style={{ fontSize: 13, color: "#333" }}>
          Bạn có thắc mắc với sản phẩm vừa xem. Đừng ngại chat với shop!
        </Text>
      </View>
      {/* FlatList hiển thị các item */}
      <FlatList
        data={data}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.itemRow}>
                      <Image
            source={typeof item.image === "string" ? { uri: item.image } : item.image}
            style={styles.itemImage}
          />
            <View style={{ flex: 1, marginLeft: 10 }}>
              <Text numberOfLines={1} style={{ fontWeight: "500", fontSize: 15 }}>{item.title}</Text>
              <Text style={{ color: item.shopColor || "#888", fontSize: 13 }}>{item.shop}</Text>
            </View>
            <TouchableOpacity style={styles.chatBtn}>
              <Text style={styles.chatBtnText}>Chat</Text>
            </TouchableOpacity>
          </View>
        )}
        contentContainerStyle={{ paddingBottom: 14 }}
      />
      {/* Bottom Navigation Bar */}
      <View style={styles.bottomBar}>
        <Ionicons name="menu" size={28} color="#000" />
        <Ionicons name="home" size={28} color="#a200ff" style={styles.homeIcon} />
        <Ionicons name="arrow-forward" size={28} color="#000" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    height: 48,
    backgroundColor: "#00b4e5",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 8,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
  },
  headerTitle: {
    color: "#fff",
    fontSize: 19,
    fontWeight: "bold",
    flex: 1,
    textAlign: "center",
    marginRight: 32,
  },
  notify: {
    backgroundColor: "#f5f5f5",
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#e0e0e0",
  },
  itemRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    marginHorizontal: 8,
    marginTop: 7,
    borderRadius: 6,
    padding: 8,
    shadowColor: "#000",
    shadowOpacity: 0.04,
    shadowOffset: { width: 0, height: 1 },
    elevation: 1,
  },
  itemImage: {
    width: 54,
    height: 54,
    borderRadius: 6,
    backgroundColor: "#eee",
  },
  chatBtn: {
    backgroundColor: "#e70000",
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 6,
    marginLeft: 10,
  },
  chatBtnText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 15,
  },
  bottomBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    height: 48,
    backgroundColor: "#00b4e5",
    borderTopWidth: 1,
    borderTopColor: "#d8e5ee",
  },
  homeIcon: {
    borderColor: "#a200ff",
    borderWidth: 2,
    borderRadius: 15,
    padding: 2,
    backgroundColor: "#fff",
  },
});