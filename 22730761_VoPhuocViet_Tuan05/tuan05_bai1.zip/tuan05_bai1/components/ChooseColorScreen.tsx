import React, { useState } from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";
import { RouteProp, useRoute, useNavigation } from "@react-navigation/native";
import product1 from "../assets/vs_black.png";

const COLOR_MAP: Record<string, string> = {
  "Xanh nhạt": "#C8F2FE",
  "Đỏ": "#E22B2B",
  "Đen": "#111",
  "Xanh dương": "#1F3B87",
};

export default function ChooseColorScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  // @ts-ignore
  const { image, name, options } = route.params;
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Image source={product1} style={styles.modalImage} />
        <Text style={styles.modalName} numberOfLines={2}>{name}</Text>
      </View>
      <Text style={{ fontSize: 15, marginBottom: 10 }}>Chọn một màu bên dưới:</Text>
      <View>
        {options.map((color: string) => (
          <TouchableOpacity
            key={color}
            style={[
              styles.colorOption,
              { backgroundColor: COLOR_MAP[color] || "#eee" },
              selected === color && styles.colorActive,
            ]}
            onPress={() => setSelected(color)}
          />
        ))}
      </View>
      <TouchableOpacity
        style={styles.doneBtn}
        onPress={() => navigation.goBack()}
        disabled={!selected}
      >
        <Text style={styles.doneBtnText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#bdbdbd",
    alignItems: "center",
    padding: 20,
    justifyContent: "center",
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  modalImage: {
    width: 42,
    height: 56,
    borderRadius: 6,
    marginRight: 8,
    resizeMode: "cover",
  },
  modalName: {
    fontSize: 14,
    fontWeight: "400",
    flex: 1,
    color: "#222",
  },
  colorOption: {
    width: 60,
    height: 40,
    borderRadius: 6,
    marginBottom: 14,
    alignSelf: "center",
    borderWidth: 2,
    borderColor: "#fff",
  },
  colorActive: {
    borderColor: "#222",
    borderWidth: 2.5,
  },
  doneBtn: {
    backgroundColor: "#6b6bdb",
    paddingVertical: 10,
    borderRadius: 6,
    marginTop: 24,
    width: 200,
    alignItems: "center",
    opacity: 1,
  },
  doneBtnText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    letterSpacing: 1,
  },
});