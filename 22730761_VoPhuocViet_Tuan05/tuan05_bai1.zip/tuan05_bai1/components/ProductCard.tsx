import React from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity, ImageSourcePropType } from "react-native";
import { Ionicons } from "@expo/vector-icons";


// Custom Dropdown Component (to mimic the styled "4 MÀU - CHỌN MÀU" button)
const CustomDropdown = ({
  selected,
  setSelected,
  options,
}: {
  selected: string;
  setSelected: (v: string) => void;
  options: string[];
}) => {
  // You may want to use a Modal for actual dropdown, but for demo, keep it a button
  return (
    <TouchableOpacity style={styles.dropdown}>
      <Text style={styles.dropdownText}>
        {options.length} MÀU - CHỌN MÀU
      </Text>
      <Ionicons name="chevron-forward-outline" size={18} color="#222" />
    </TouchableOpacity>
  );
};

type ProductCardProps = {
  image: ImageSourcePropType;
  name: string;
  oldPrice: number;
  newPrice: number;
  rating: number;
  reviews: number;
  options: string[];
};

const ProductCard: React.FC<ProductCardProps> = ({
  image,
  name,
  oldPrice,
  newPrice,
  rating,
  reviews,
  options,
}) => {
  const [selected, setSelected] = React.useState(options[0]);

  return (
    <View style={styles.card}>
      {/* Ảnh sản phẩm */}
      <Image source={image} style={styles.image} />

      {/* Tên sản phẩm */}
      <Text style={styles.name} numberOfLines={1}>
        {name}
      </Text>

      {/* Đánh giá + số lượng đánh giá */}
      <View style={styles.ratingRow}>
        {Array.from({ length: 5 }).map((_, i) => (
          <Ionicons
            key={i}
            name={i < Math.round(rating) ? "star" : "star-outline"}
            size={18}
            color="#FFD600"
            style={{ marginRight: 2 }}
          />
        ))}
        <Text style={styles.ratingCount}>
          (Xem {reviews} đánh giá)
        </Text>
      </View>

      {/* Giá + hoàn tiền */}
      <View style={styles.priceCol}>
        <Text style={styles.newPrice}>
          {newPrice.toLocaleString("vi-VN")} ₫
        </Text>
        <Text style={styles.oldPrice}>
          {oldPrice.toLocaleString("vi-VN")} ₫
        </Text>
        <Text style={styles.refundText}>Ở ĐÂU RẺ HƠN HOÀN TIỀN</Text>
      </View>

      {/* Chọn màu */}
      <CustomDropdown
        selected={selected}
        setSelected={setSelected}
        options={options}
      />

      {/* Nút chọn mua */}
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 14,
    margin: 10,
    alignItems: "center",
    elevation: 2,
    shadowColor: "#000",
    shadowOpacity: 0.07,
    shadowOffset: { width: 0, height: 2 },
    width: 320,
    flex: 1,
    justifyContent: "center",
    alignContent: "center"
  },
  image: {
    width: 120,
    height: 160,
    borderRadius: 8,
    resizeMode: "cover",
    marginBottom: 8,
  },
  name: {
    fontSize: 15,
    fontWeight: "400",
    textAlign: "center",
    color: "#222",
    marginBottom: 4,
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 2,
  },
  ratingCount: {
    fontSize: 12,
    color: "#333",
    marginLeft: 4,
  },
  priceCol: {
    alignItems: "center",
    marginVertical: 4,
  },
  newPrice: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#D80000",
    marginBottom: 0,
  },
  oldPrice: {
    fontSize: 13,
    color: "#999",
    textDecorationLine: "line-through",
    marginBottom: 2,
  },
  refundText: {
    fontSize: 12,
    color: "#D80000",
    fontWeight: "bold",
    marginBottom: 2,
  },
  dropdown: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderWidth: 1,
    borderColor: "#bbb",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    width: "100%",
    marginVertical: 8,
    backgroundColor: "#fff",
  },
  dropdownText: {
    fontSize: 15,
    color: "#222",
    fontWeight: "500",
  },
  button: {
    backgroundColor: "#d80000",
    paddingVertical: 13,
    borderRadius: 8,
    width: "100%",
    alignItems: "center",
    marginTop: 4,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
    letterSpacing: 1,
  },
});

export default ProductCard;