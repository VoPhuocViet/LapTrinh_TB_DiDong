import React from "react";
import { StyleSheet, View } from "react-native";
import ProductSearchScreen from "./components/ProductSearchScreen.jsx";

export default function App() {
  return (
    <View style={styles.container}>
      <ProductSearchScreen/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
});