import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
} from "react-native";

interface Photo {
  id: string;
  author: string;
  download_url: string;
}

export default function App() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [gridView, setGridView] = useState<boolean>(false); // toggle giữa list & grid

  useEffect(() => {
    fetch("https://682c590dd29df7a95be6a099.mockapi.io/api/1/user")
      .then((res) => res.json())
      .then((data: Photo[]) => {
        setPhotos(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="blue" />
        <Text>Đang tải ảnh...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}> Gallery App</Text>
      <Text style={styles.desc}>
        Đây là ứng dụng hiển thị danh sách ảnh từ API. Bạn có thể chuyển đổi
        giữa ListView và GridView.
      </Text>

      {/* Nút chuyển đổi */}
      <TouchableOpacity
        style={styles.button}
        onPress={() => setGridView(!gridView)}
      >
        <Text style={styles.buttonText}>
          {gridView ? "Chuyển sang ListView" : "Chuyển sang GridView"}
        </Text>
      </TouchableOpacity>

      {/* Horizontal List nổi bật */}
      <Text style={styles.subTitle}>Ảnh nổi bật</Text>
      <FlatList
        data={photos.slice(0, 5)} // lấy 5 ảnh đầu làm nổi bật
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.highlightCard}>
            <Image
              source={{ uri: item.download_url }}
              style={styles.highlightImage}
            />
            <Text style={styles.author}>{item.author}</Text>
          </View>
        )}
      />

      {/* List/Grid View */}
      <Text style={styles.subTitle}>Danh sách ảnh</Text>
      <FlatList
        data={photos}
        key={gridView ? "g" : "l"} // bắt buộc đổi key để FlatList re-render khi numColumns thay đổi
        numColumns={gridView ? 2 : 1}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={gridView ? styles.gridCard : styles.listCard}>
            <Image
              source={{ uri: item.download_url }}
              style={gridView ? styles.gridImage : styles.listImage}
            />
            <Text style={styles.author}>{item.author}</Text>
          </View>
        )}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 40,
    padding: 10,
  },
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  title: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
  },
  desc: {
    fontSize: 16,
    marginBottom: 15,
    textAlign: "center",
    color: "gray",
  },
  button: {
    backgroundColor: "#007bff",
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  buttonText: {
    color: "white",
    textAlign: "center",
    fontWeight: "bold",
  },
  subTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginVertical: 10,
  },
  highlightCard: {
    marginRight: 10,
    alignItems: "center",
  },
  highlightImage: {
    width: 120,
    height: 80,
    borderRadius: 8,
  },
  listCard: {
    marginBottom: 15,
  },
  listImage: {
    width: "100%",
    height: 200,
    borderRadius: 8,
  },
  gridCard: {
    flex: 1,
    margin: 5,
    alignItems: "center",
  },
  gridImage: {
    width: "100%",
    height: 150,
    borderRadius: 8,
  },
  author: {
    marginTop: 5,
    fontWeight: "600",
  },
});
