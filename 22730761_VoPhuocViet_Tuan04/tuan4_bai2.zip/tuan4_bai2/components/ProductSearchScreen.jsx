import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { Ionicons, MaterialIcons, Entypo } from "@expo/vector-icons";
import giacChuyen from "../assets/giacchuyen 1.png";
import dayNguon from "../assets/daynguon 1.png";
import dauChuyen from "../assets/dauchuyendoipsps2 1.png";
import chuyenDoi1 from "../assets/dauchuyendoi 1 1.png";
import carbus from "../assets/carbusbtops2 1.png";
import dauCam from "../assets/daucam 1 1.png";
// Dữ liệu mẫu cho FlatList

// Dữ liệu mẫu cho sản phẩm
const data = [
  {
    id: "1",
    image: giacChuyen,
    title: "Cáp chuyển từ Cổng USB sang PS2...",
    price: "69.900 đ",
    discount: "-39%",
    rating: 3,
    reviews: 15,
  },
  {
    id: "2",
    image: dayNguon,
    title: "Cáp chuyển từ Cổng USB sang PS2...",
    price: "69.900 đ",
    discount: "-39%",
    rating: 3,
    reviews: 15,
  },
  {
    id: "3",
    image: dauChuyen,
    title: "Cáp chuyển từ Cổng USB sang PS2...",
    price: "69.900 đ",
    discount: "-39%",
    rating: 3,
    reviews: 15,
  },
  {
    id: "4",
    image: chuyenDoi1,
    title: "Cáp chuyển từ Cổng USB sang PS2...",
    price: "69.900 đ",
    discount: "-39%",
    rating: 3,
    reviews: 15,
  },
  {
    id: "5",
    image: carbus,
    title: "Cáp chuyển từ Cổng USB sang PS2...",
    price: "69.900 đ",
    discount: "-39%",
    rating: 3,
    reviews: 15,
  },
  {
    id: "6",
    image: dauCam,
    title: "Cáp chuyển từ Cổng USB sang PS2...",
    price: "69.900 đ",
    discount: "-39%",
    rating: 3,
    reviews: 15,
  },
];

export default function ProductSearchScreen() {
  const [search, setSearch] = useState("Dây cáp usb");

  const renderItem = ({ item, index }: any) => (
    <View style={styles.productCard}>
      <Image source={item.image} style={styles.productImage} />
      <Text
      >
        {item.title}
      </Text>
      <View style={styles.ratingRow}>
        {Array.from({ length: 5 }).map((_, i) => (
          <Ionicons
            key={i}
            name="star"
            size={14}
            color={i < item.rating ? "#FFD700" : "#aaa"}
          />
        ))}
        <Text style={styles.reviewText}>({item.reviews})</Text>
      </View>
      <View style={styles.priceRow}>
        <Text style={styles.productPrice}>{item.price}</Text>
        <Text style={styles.productDiscount}>{item.discount}</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      {/* Header tìm kiếm */}
      <View style={styles.header}>
        <TouchableOpacity>
          <Ionicons name="arrow-back" size={26} color="#fff" style={{ marginLeft: 5 }} />
        </TouchableOpacity>
        <View style={styles.searchBox}>
          <Ionicons name="search" size={20} color="#000" />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="Tìm kiếm"
            style={styles.input}
            placeholderTextColor="#888"
          />
        </View>
        <TouchableOpacity>
          <MaterialIcons name="shopping-cart" size={26} color="#fff" style={{ marginHorizontal: 6 }} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Entypo name="dots-three-vertical" size={22} color="#fff" style={{ marginRight: 5 }} />
        </TouchableOpacity>
      </View>

      {/* Danh sách sản phẩm */}
      <FlatList
        data={data}
        numColumns={2}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 5 }}
        columnWrapperStyle={{ justifyContent: "space-between" }}
        showsVerticalScrollIndicator={false}
      />

      {/* Thanh điều hướng dưới cùng */}
      <View style={styles.bottomBar}>
        <Ionicons name="menu" size={28} color="#000" />
        <Ionicons name="home" size={28} color="#a200ff" style={styles.homeIcon} />
        <Ionicons name="arrow-forward" size={28} color="#000" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#21a7f2",
    height: 48,
    paddingHorizontal: 5,
    paddingVertical: 4,
  },
  searchBox: {
    backgroundColor: "#fff",
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 5,
    marginHorizontal: 8,
    flex: 1,
    height: 35,
    paddingHorizontal: 5,
  },
  input: {
    flex: 1,
    marginLeft: 5,
    fontSize: 15,
    color: "#000",
    paddingVertical: 0,
  },
  productCard: {
    backgroundColor: "#fff",
    borderRadius: 7,
    marginVertical: 7,
    width: "48%",
    padding: 6,
    shadowColor: "#000",
    shadowOpacity: 0.03,
    shadowOffset: { width: 0, height: 1 },
    elevation: 1,
    borderWidth: 1,
    borderColor: "#e0e0e0",
  },
  productImage: {
    width: "100%",
    height: 80,
    resizeMode: "contain",
    borderRadius: 4,
    marginBottom: 2,
  },
  productTitle: {
    fontSize: 14,
    fontWeight: "500",
    minHeight: 32,
    marginBottom: 2,
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 2,
  },
  reviewText: {
    fontSize: 12,
    color: "#888",
    marginLeft: 2,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 2,
  },
  productPrice: {
    fontSize: 15,
    color: "#111",
    fontWeight: "bold",
    marginRight: 8,
  },
  productDiscount: {
    fontSize: 13,
    color: "#21a7f2",
    fontWeight: "bold",
  },
  bottomBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    height: 48,
    backgroundColor: "#21a7f2",
    borderTopWidth: 1,
    borderTopColor: "#d8e5ee",
  },
  homeIcon: {
    borderColor: "#a200ff",
    borderWidth: 2,
    borderRadius: 15,
    padding: 2,
    backgroundColor: "#fff",
  },
});