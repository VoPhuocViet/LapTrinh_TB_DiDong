import React, { useState } from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";

import vsBlue from "../assets/vs_blue.png";
import vsRed from "../assets/vs_red.png";
import vsBlack from "../assets/vs_black.png";
import vsSilver from "../assets/vs_silver.png";

export default function Screen2({ navigation }: any) {
  const [selectedColor, setSelectedColor] = useState<string | null>(null);

  // mảng màu
  const colors = [
    { label: "bạc", value: "silver", colorCode: "#C0C0C0", img: vsSilver },
    { label: "đỏ", value: "red", colorCode: "red", img: vsRed },
    { label: "đen", value: "black", colorCode: "black", img: vsBlack },
    { label: "xanh đậm", value: "blue", colorCode: "#1E3A8A", img: vsBlue },
  ];

  // lấy ảnh hiện tại (nếu chưa chọn thì mặc định xanh đậm)
  const current =
    colors.find((c) => c.value === selectedColor) ||
    colors.find((c) => c.value === "blue")!;

  return (
    <View style={styles.container}>
      {/* Thông tin sản phẩm */}
      <View style={styles.header}>
        <Image source={current.img} style={styles.image} resizeMode="contain" />
        <View style={{ flex: 1 }}>
          <Text style={styles.productName}>
            Điện Thoại Vsmart Joy 3{"\n"}Hàng chính hãng
          </Text>
          <Text style={styles.colorText}>
            Màu: {selectedColor ? current.label : "xanh đậm"}
          </Text>
          <Text style={styles.supplier}>Cung cấp bởi Tiki Tradding</Text>
          <Text style={styles.price}>1.790.000 đ</Text>
        </View>
      </View>

      {/* Text hướng dẫn */}
      <Text style={styles.instruction}>Chọn một màu bên dưới:</Text>

      {/* Danh sách màu */}
      <View style={styles.colorList}>
        {colors.map((c, idx) => (
          <TouchableOpacity
            key={idx}
            style={[
              styles.colorBox,
              { backgroundColor: c.colorCode },
              selectedColor === c.value && styles.selectedBox,
            ]}
            onPress={() => setSelectedColor(c.value)}
          />
        ))}
      </View>

      {/* Nút XONG */}
      <TouchableOpacity
  style={styles.doneBtn}
  onPress={() => {
    if (selectedColor) {
      navigation.navigate("Screen1", { selectedColor });
    }
  }}
>
  <Text style={styles.doneText}>XONG</Text>
</TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#ccc", padding: 16 },
  header: { flexDirection: "row", alignItems: "flex-start", marginBottom: 16 },
  image: { width: 100, height: 140, marginRight: 10 },
  productName: { fontSize: 16, fontWeight: "bold", flexShrink: 1 },
  colorText: { fontSize: 14, marginTop: 4 },
  supplier: { fontSize: 14, fontWeight: "bold", marginTop: 4 },
  price: { fontSize: 18, fontWeight: "bold", color: "red", marginTop: 4 },

  instruction: { fontSize: 16, marginBottom: 16, fontWeight: "bold" },

  colorList: { alignItems: "center" },
  colorBox: {
    width: 80,
    height: 80,
    marginVertical: 8,
    borderRadius: 4,
  },
  selectedBox: {
    borderWidth: 3,
    borderColor: "purple",
  },

  doneBtn: {
    marginTop: 20,
    alignSelf: "center",
    backgroundColor: "#3B82F6",
    paddingVertical: 12,
    paddingHorizontal: 50,
    borderRadius: 8,
  },
  doneText: { color: "white", fontWeight: "bold", fontSize: 18 },
});
