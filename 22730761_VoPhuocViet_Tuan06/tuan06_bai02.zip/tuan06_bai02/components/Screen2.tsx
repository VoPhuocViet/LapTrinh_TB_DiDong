import React, { useState, useEffect } from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet, ActivityIndicator } from "react-native";

export default function Screen2({ navigation }: any) {
  const [colors, setColors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedColor, setSelectedColor] = useState<string | null>(null);

  const API_URL = "https://682c590dd29df7a95be6a099.mockapi.io/api/1/SelectPhone"; // 👈 thay bằng link mockapi của bạn

  useEffect(() => {
    fetch(API_URL)
      .then((res) => res.json())
      .then((data) => {
        setColors(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="blue" />
      </View>
    );
  }

  const current =
    colors.find((c) => c.value === selectedColor) || colors.find((c) => c.value === "blue");

  return (
    <View style={styles.container}>
      {/* Thông tin sản phẩm */}
      {current && (
        <View style={styles.header}>
          <Image source={{ uri: current.img }} style={styles.image} resizeMode="contain" />
          <View style={{ flex: 1 }}>
            <Text style={styles.productName}>Điện Thoại Vsmart Joy 3{"\n"}Hàng chính hãng</Text>
            <Text style={styles.colorText}>
              Màu: {selectedColor ? current.label : current.label}
            </Text>
            <Text style={styles.supplier}>Cung cấp bởi Tiki Tradding</Text>
            <Text style={styles.price}>1.790.000 đ</Text>
          </View>
        </View>
      )}

      <Text style={styles.instruction}>Chọn một màu bên dưới:</Text>

      {/* Danh sách màu */}
<View style={styles.colorList}>
  {colors.map((c) => (
    <TouchableOpacity
      key={c.id}
      style={[
        styles.colorBox,
        { backgroundColor: c.colorCode }, // 👈 màu từ API
        selectedColor === c.value && styles.selectedBox,
      ]}
      onPress={() => setSelectedColor(c.value)}
    />
  ))}
</View>


      {/* Nút XONG */}
      <TouchableOpacity
        style={styles.doneBtn}
        onPress={() => {
          if (selectedColor) {
            navigation.navigate("Screen1", { selectedColor });
          }
        }}
      >
        <Text style={styles.doneText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#ccc", padding: 16 },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  header: { flexDirection: "row", alignItems: "flex-start", marginBottom: 16 },
  image: { width: 100, height: 140, marginRight: 10 },
  productName: { fontSize: 16, fontWeight: "bold", flexShrink: 1 },
  colorText: { fontSize: 14, marginTop: 4 },
  supplier: { fontSize: 14, fontWeight: "bold", marginTop: 4 },
  price: { fontSize: 18, fontWeight: "bold", color: "red", marginTop: 4 },
  instruction: { fontSize: 16, marginBottom: 16, fontWeight: "bold" },
  colorList: { alignItems: "center" },
  colorBox: { width: 80, height: 80, marginVertical: 8, borderRadius: 4 },
  selectedBox: { borderWidth: 3, borderColor: "purple" },
  doneBtn: {
    marginTop: 20,
    alignSelf: "center",
    backgroundColor: "#3B82F6",
    paddingVertical: 12,
    paddingHorizontal: 50,
    borderRadius: 8,
  },
  doneText: { color: "white", fontWeight: "bold", fontSize: 18 },
});
