import React, { useState, useEffect } from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { useRoute } from "@react-navigation/native";
import star from "../assets/star.png"; // ⭐ vẫn giữ local

export default function Screen1({ navigation }: any) {
  const route = useRoute<any>();
  const selectedColor = route.params?.selectedColor || "blue";

  const [colors, setColors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const API_URL = "https://682c590dd29df7a95be6a099.mockapi.io/api/1/SelectPhone"; 

  useEffect(() => {
    fetch(API_URL)
      .then((res) => res.json())
      .then((data) => {
        setColors(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="blue" />
      </View>
    );
  }

  const current =
    colors.find((c) => c.value === selectedColor) || colors.find((c) => c.value === "blue");

  return (
    <View style={styles.container}>
      {/* Ảnh sản phẩm */}
      <Image source={{ uri: current.img }} style={styles.image} resizeMode="contain" />

      {/* Tên sản phẩm */}
      <Text style={styles.title}>Điện Thoại Vsmart Joy 3 - Hàng chính hãng</Text>

      {/* Rating */}
      <View style={styles.ratingRow}>
        {Array(5)
          .fill(0)
          .map((_, i) => (
            <Image key={i} source={star} style={styles.star} />
          ))}
        <Text style={styles.ratingText}>(Xem 828 đánh giá)</Text>
      </View>

      {/* Giá */}
      <View style={styles.priceRow}>
        <Text style={styles.price}>1.790.000 đ</Text>
        <Text style={styles.oldPrice}>1.790.000 đ</Text>
      </View>

      {/* Ở đâu rẻ hơn hoàn tiền */}
      <Text style={styles.refundText}>Ở ĐÂU RẺ HƠN HOÀN TIỀN</Text>

      {/* Button chọn màu */}
      <TouchableOpacity
        style={styles.colorBtn}
        onPress={() => navigation.navigate("Screen2")}
      >
        <Text style={styles.colorBtnText}>4 MÀU - CHỌN MÀU</Text>
      </TouchableOpacity>

      {/* Button chọn mua */}
      <TouchableOpacity style={styles.buyBtn}>
        <Text style={styles.buyText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "#fff" },
  center: { flex: 1, justifyContent: "center", alignItems: "center" },
  image: { width: 250, height: 250, marginVertical: 10 },
  title: { fontSize: 15, textAlign: "center", marginVertical: 8 },
  ratingRow: { flexDirection: "row", marginBottom: 8 },
  star: { width: 20, height: 20, marginRight: 2 },
  ratingText: { fontSize: 14, color: "#444", marginLeft: 5 },
  priceRow: { flexDirection: "row", alignItems: "center", marginBottom: 4 },
  price: { fontSize: 20, fontWeight: "bold", marginRight: 10, color: "red" },
  oldPrice: { fontSize: 16, color: "#999", textDecorationLine: "line-through" },
  refundText: { color: "red", fontSize: 12, fontWeight: "bold", marginBottom: 12 },
  colorBtn: {
    borderWidth: 1,
    borderColor: "gray",
    borderRadius: 5,
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginVertical: 10,
  },
  colorBtnText: { fontSize: 16, textAlign: "center" },
  buyBtn: { backgroundColor: "red", borderRadius: 5, paddingVertical: 12, paddingHorizontal: 50 },
  buyText: { color: "white", fontSize: 18, fontWeight: "bold", textAlign: "center" },
});
