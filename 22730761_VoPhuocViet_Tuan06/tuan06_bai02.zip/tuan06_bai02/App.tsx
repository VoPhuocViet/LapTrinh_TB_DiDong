import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createStackNavigator } from "@react-navigation/stack";
import Screen1 from "./components/Screen1";
import Screen2 from "./components/Screen2";


export type RootStackParamList = {
  Screen1: undefined;
  Screen2: undefined;
  Screen3: { selectedColor: string };
  Screen4: { selectedColor: string };
};

const Stack = createNativeStackNavigator(); // 

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Screen1" component={Screen1} />
        <Stack.Screen name="Screen2" component={Screen2} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
