import React from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from "react-native";

const PRODUCTS = [
  { id: "1", name: "iPhone 15 Pro", price: "30.000.000 đ" },
  { id: "2", name: "Samsung Galaxy S24", price: "25.000.000 đ" },
  { id: "3", name: "Xiaomi 14 Ultra", price: "20.000.000 đ" },
];

export default function ProductsScreen({ navigation }: any) {
  return (
    <View style={styles.container}>
      <FlatList
        data={PRODUCTS}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            onPress={() => navigation.navigate("ProductDetails", { id: item.id })}
          >
            <Text style={styles.name}>{item.name}</Text>
            <Text>{item.price}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  item: {
    padding: 12,
    marginVertical: 6,
    backgroundColor: "#eee",
    borderRadius: 6,
  },
  name: { fontSize: 18, fontWeight: "bold" },
});
