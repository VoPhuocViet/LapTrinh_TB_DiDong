import React from "react";
import { View, Text, FlatList, StyleSheet } from "react-native";

const FAVORITES = [
  { id: "2", name: "Samsung Galaxy S24", price: "25.000.000 đ" },
];

export default function FavoritesScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={FAVORITES}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.name}>{item.name}</Text>
            <Text>{item.price}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  item: {
    padding: 12,
    marginVertical: 6,
    backgroundColor: "#eee",
    borderRadius: 6,
  },
  name: { fontSize: 18, fontWeight: "bold" },
});
