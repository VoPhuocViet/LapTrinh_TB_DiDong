import React from "react";
import { View, Text, StyleSheet } from "react-native";

const PRODUCTS = [
  { id: "1", name: "iPhone 15 Pro", price: "30.000.000 đ" },
  { id: "2", name: "Samsung Galaxy S24", price: "25.000.000 đ" },
  { id: "3", name: "Xiaomi 14 Ultra", price: "20.000.000 đ" },
];

export default function ProductDetailsScreen({ route }: any) {
  const { id } = route.params;
  const product = PRODUCTS.find((p) => p.id === id);

  if (!product) {
    return (
      <View style={styles.container}>
        <Text>Không tìm thấy sản phẩm</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.name}>{product.name}</Text>
      <Text style={styles.price}>{product.price}</Text>
      <Text>Mô tả sản phẩm {product.name} ở đây...</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  name: { fontSize: 22, fontWeight: "bold", marginBottom: 10 },
  price: { fontSize: 18, color: "red", marginBottom: 10 },
});
