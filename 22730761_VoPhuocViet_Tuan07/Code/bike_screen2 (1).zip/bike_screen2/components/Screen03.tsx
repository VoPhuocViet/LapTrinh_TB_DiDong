import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useRoute } from '@react-navigation/native';

const Screen03: React.FC = () => {
  const route = useRoute<any>();
  const { bike } = route.params;

  return (
    <View style={styles.container}>
      <Image source={bike.img} style={styles.image} resizeMode="contain" />

      <Text style={styles.name}>{bike.name}</Text>
      <View style= {styles.disPri} >
            <Text style={styles.discount}>15% OFF | $350</Text>
            <Text style={styles.price}>${bike.price}</Text>
      </View>

      <Text style={styles.sectionTitle}>Description</Text>
      <Text style={styles.desc}>
        It is a very important form of writing as we write almost everything in paragraphs,
        be it an answer, essay, story, emails, etc.
      </Text>

      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Add to cart</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Screen03;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 20, alignItems: 'center' },
  image: { width: 250, height: 200, marginBottom: 20 },
  name: { fontSize: 22, fontWeight: 'bold' },
  disPri: { flexDirection: 'row', marginTop: 10, gap:20},
  discount: { fontSize: 20, color: '#808080', marginTop: 10 },
  price: { fontSize: 20, color: 'black', marginVertical: 10,  textDecorationLine: 'line-through' },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginTop: 20, alignSelf: 'flex-start' },
  desc: { fontSize: 14, color: '#555', marginTop: 10, textAlign: 'left' },
  button: { backgroundColor: '#F44336', padding: 14, borderRadius: 12, marginTop: 20, width: '100%' },
  buttonText: { color: '#fff', fontWeight: '600', textAlign: 'center' },
});
