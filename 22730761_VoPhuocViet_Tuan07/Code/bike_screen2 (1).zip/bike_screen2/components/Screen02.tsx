import React from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';


const bikes = [
  { id: '1', name: 'Pinarello', price: 1800, img: require('../assets/blue_bike.png') },
  { id: '2', name: 'Pina Mountain', price: 1700, img: require('../assets/red_bike.png') },
  { id: '3', name: 'Pina Bike', price: 1500, img: require('../assets/purple_bike.png') },
    { id: '4', name: 'Pinarello', price: 1900, img: require('../assets/red_bike2.png') },
  { id: '5', name: 'Pinarello', price: 2700, img: require('../assets/blue_bike2.png') },
  { id: '6', name: 'Pinarello', price: 1350, img: require('../assets/red_bike_small.png') },
];

const Screen02: React.FC = () => {
  const navigation = useNavigation<any>();

  return (
    <View style={styles.container}>
      <Text style={styles.header}>The world's Best Bike</Text>

            <View style={styles.filterRow}>
        <TouchableOpacity style={[styles.filterBtn, { backgroundColor: '#F44336' }]}>
          <Text style={styles.filterText}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.filterBtn}>
          <Text style={styles.filterText}>Roadbike</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.filterBtn}>
          <Text style={styles.filterText}>Mountain</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={bikes}
        keyExtractor={(item) => item.id}
        numColumns={2}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate('Screen03', { bike: item })}
          >
           <Ionicons
              name="heart-outline"
              size={22}
              color="#555"
              style={styles.heartIcon}
            />
            <Image source={item.img} style={styles.image} resizeMode="contain" />
            <Text style={styles.name}>{item.name}</Text>
            <Text style={styles.price}>${item.price}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

export default Screen02;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', paddingTop: 40, paddingHorizontal: 16 },
  header: { fontSize: 20, fontWeight: 'bold', marginBottom: 20, color: '#E53935' },
   filterRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20 },
  filterBtn: { borderWidth: 1, borderColor: '#ccc', borderRadius: 8, paddingVertical: 6, paddingHorizontal: 14 },
  filterText: { fontSize: 14, fontWeight: '500' },
  card: { flex: 1, margin: 8, backgroundColor: '#FAFAFA', borderRadius: 12, padding: 10, alignItems: 'center', elevation: 2 },
    heartIcon: {
    position: 'absolute',
    top: 8,
    left: 8,
  },
  image: { width: 100, height: 80, marginBottom: 10 },
  name: { fontSize: 16, fontWeight: '600', marginBottom: 4 },
  price: { fontSize: 14, color: '#F44336' },
});
