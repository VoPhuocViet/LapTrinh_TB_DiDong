import React from 'react';
import Screen01 from './components/Screen01';

export default function App() {
  return <Screen01 />;
}
