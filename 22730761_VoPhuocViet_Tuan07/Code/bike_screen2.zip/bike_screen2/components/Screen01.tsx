import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const { width } = Dimensions.get('window');

const Screen01: React.FC = () => {
  const navigation = useNavigation<any>();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        A premium online store for{"\n"}sporter and their stylish choice
      </Text>

      <View style={styles.imageContainer}>
        <Image
          source={require('../assets/blue_bike.png')}
          style={styles.image}
          resizeMode="contain"
        />
      </View>

      <Text style={styles.shopName}>POWER BIKE SHOP</Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Screen02')}
      >
        <Text style={styles.buttonText}>Get Started</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Screen01;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#ffffff', paddingHorizontal: 24, paddingTop: 60, alignItems: 'center' },
  title: { fontSize: 18, textAlign: 'center', fontWeight: '500', lineHeight: 26, marginBottom: 30 },
  imageContainer: { backgroundColor: '#FFECEC', borderRadius: 30, padding: 20, marginBottom: 30 },
  image: { width: width * 0.6, height: width * 0.5 },
  shopName: { fontSize: 22, fontWeight: 'bold', letterSpacing: 1, marginBottom: 40 },
  button: { backgroundColor: '#F44336', paddingVertical: 14, paddingHorizontal: 32, borderRadius: 12, position: 'absolute', bottom: 40, width: '100%' },
  buttonText: { color: '#ffffff', fontSize: 16, fontWeight: '600', textAlign: 'center' },
});
